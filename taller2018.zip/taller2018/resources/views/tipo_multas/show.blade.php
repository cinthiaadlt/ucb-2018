@extends ('layouts.app')

@section ('content')

<h1>{{$tipoMultas->nombre_tipo_multa}}</h1>
